# Chikandamina Academy — secure starter v0.2

This is a full-stack starter, not just a static mockup. It includes a Node.js/Express server, SQLite database, hashed passwords, server-side sessions, role-based API checks, admin-created registered accounts, content CRUD, basic offline shell caching, a local offline content-change queue and sync endpoint.

## Requirements

- Node.js 20 or newer (Node.js LTS recommended)
- npm
- A modern browser
- For public deployment: HTTPS hosting, persistent storage for SQLite/session files, backups, and environment variables.

## Run on Windows or Mac

1. Extract the ZIP.
2. Install Node.js LTS from https://nodejs.org if needed.
3. Open Terminal (Mac) or PowerShell (Windows) in the extracted project folder.
4. Copy `.env.example` to `.env`.
   - Windows PowerShell: `Copy-Item .env.example .env`
   - macOS/Linux: `cp .env.example .env`
5. Edit `.env` and set:
   - `SESSION_SECRET` to a long random secret (at least 32 characters for production).
   - `INITIAL_ADMIN_SETUP_KEY` to a one-time setup key that only you know.
   - `APP_ORIGIN` to your site origin when deployed.
6. Install dependencies: `npm install`
7. Start: `npm start`
8. Visit http://localhost:3000
9. The first visit shows initial administrator setup. Enter the exact `INITIAL_ADMIN_SETUP_KEY` from `.env`, choose an administrator username, and create a strong password of at least 12 characters.
10. Sign in and use Accounts to create teacher, parent and learner accounts. There is no public self-registration.

Example `.env` values for local testing:
```
PORT=3000
NODE_ENV=development
SESSION_SECRET=use-a-long-random-string-at-least-32-characters-here
INITIAL_ADMIN_SETUP_KEY=choose-a-private-one-time-setup-key
APP_ORIGIN=http://localhost:3000
TRUST_PROXY=0
```
Do not deploy the example secrets. Do not commit `.env` or the `data` folder.

## Roles

- Administrator: create/deactivate accounts, manage content and publish content.
- Teacher: add/edit/remove content. In this starter, teachers cannot publish or unpublish content.
- Parent and learner: view published content.
- Account creation is administrator-only. Roles are checked on the server, not trusted from a browser dropdown.

## Offline behaviour and important limits

- The service worker caches the app shell so the interface can load after the first successful online visit.
- Published learning content is cached locally after sign-in, so it may be available on that same browser/device offline.
- Teachers/admins can queue content changes on a device when the API is unreachable. The app attempts to sync when the connection returns and the user is signed in.
- Offline work is device-local. It is not shared until it synchronises. This prototype does not yet implement conflict resolution, robust encrypted local storage, offline login, assignment submissions, or offline exam attempts.
- Do not use shared/public devices for persistent cached student content. Sign out when finished.
- This is a starter, not a security audit or a production-ready student information system. Before real school use, arrange HTTPS, secure secrets, reliable persistent storage, database backups, restore tests, privacy/safeguarding procedures, account recovery, audit logs and professional review.

## Hosting recommendation

For a first pilot, use a Node.js-capable host with HTTPS and a persistent disk/volume. SQLite is suitable for a small pilot if the host supports persistent disk and backups. If the school grows or needs concurrent access from many classes, migrate to managed PostgreSQL. Do not host on a free service that deletes local files on restart or sleeps when unused unless the limitations are acceptable. Confirm current pricing, Zimbabwe access, data location, backups, persistent storage and outbound email before choosing a provider.

For local-network-only testing, run the server on a school computer and access it from other devices on the same Wi-Fi using the computer's LAN IP and a firewall rule. Do not expose this local server directly to the public internet.

## Curriculum

The application includes ECD A, ECD B and Grades 1–7 and the six requested subject areas:
Physical Education and Arts; Social Science; Science and Technology; Mathematics; English; ChiShona.

The structure is designed to hold heritage-based content, but the sample content is not a full official syllabus. Teachers/school leadership should validate all topic maps, learning outcomes and assessment approaches against the current Zimbabwe Ministry of Primary and Secondary Education documents for the 2024–2030 curriculum.

## Next development steps

1. Parent-child links and class/grade enrolment.
2. Password reset, account invitation flow, audit logs and secure admin recovery.
3. Full assessment engine, auto-marking for suitable question types, rubrics and results.
4. More robust sync protocol with revisions/conflict handling and explicit per-change acknowledgement.
5. Secure exports (PDF/DOCX/XLSX), WhatsApp sharing, announcements and report cards.
6. PostgreSQL migration and tested production deployment.
