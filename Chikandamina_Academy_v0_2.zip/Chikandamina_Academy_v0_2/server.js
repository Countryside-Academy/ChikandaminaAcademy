require("dotenv").config();
const express = require("express");
const session = require("express-session");
const SQLiteStoreFactory = require("connect-sqlite3");
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const isProduction = process.env.NODE_ENV === "production";
const SESSION_SECRET = process.env.SESSION_SECRET || "";
if (isProduction && SESSION_SECRET.length < 32) {
  console.error("SESSION_SECRET must be at least 32 characters in production.");
  process.exit(1);
}
if (!isProduction && SESSION_SECRET.length < 16) {
  console.warn("WARNING: set SESSION_SECRET in .env before using this beyond local testing.");
}
if (process.env.TRUST_PROXY === "1") app.set("trust proxy", 1);
app.disable("x-powered-by");
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'"],
      imgSrc: ["'self'", "data:"], connectSrc: ["'self'"],
      objectSrc: ["'none'"], frameAncestors: ["'none'"], upgradeInsecureRequests: isProduction ? [] : null
    }
  }
}));
app.use(express.json({ limit: "150kb" }));
app.use(express.urlencoded({ extended: false, limit: "20kb" }));

const dataDir = path.join(__dirname, "data");
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, "chikandamina.sqlite"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 username TEXT NOT NULL UNIQUE COLLATE NOCASE,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL CHECK(role IN ('admin','teacher','parent','learner')),
 active INTEGER NOT NULL DEFAULT 1,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS content (
 id TEXT PRIMARY KEY,
 type TEXT NOT NULL CHECK(type IN ('lesson','assessment','project')),
 grade TEXT NOT NULL,
 subject TEXT NOT NULL,
 term TEXT NOT NULL DEFAULT 'Any term',
 title TEXT NOT NULL,
 topic TEXT NOT NULL DEFAULT '',
 body TEXT NOT NULL DEFAULT '',
 questions TEXT NOT NULL DEFAULT '',
 answers TEXT NOT NULL DEFAULT '',
 published INTEGER NOT NULL DEFAULT 0,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_by INTEGER REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS sync_changes (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL REFERENCES users(id),
 entity_id TEXT NOT NULL,
 action TEXT NOT NULL,
 result TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);
const userCount = db.prepare("SELECT COUNT(*) n FROM users").get().n;
if (userCount === 0) {
  console.log("\\nFIRST RUN: no administrator exists.");
  console.log("Create the first administrator at /setup using a one-time setup key.");
}
const SQLiteStore = SQLiteStoreFactory(session);
app.use(session({
  name: "ca.sid",
  secret: SESSION_SECRET || "local-development-secret-change-this",
  store: new SQLiteStore({ db: "sessions.sqlite", dir: dataDir, concurrentDB: true }),
  resave: false,
  saveUninitialized: false,
  rolling: true,
  cookie: {
    httpOnly: true, sameSite: "lax", secure: isProduction, maxAge: 8 * 60 * 60 * 1000
  }
}));
app.use((req,res,next)=>{res.setHeader("Cache-Control","no-store");next()});

const loginLimiter = rateLimit({ windowMs: 15*60*1000, limit: 10, standardHeaders: true, legacyHeaders: false, message: {error:"Too many attempts. Wait 15 minutes and try again."} });
const setupLimiter = rateLimit({ windowMs: 60*60*1000, limit: 5, standardHeaders: true, legacyHeaders: false });
const roles = ["admin","teacher","parent","learner"];
const grades = ["ECD A","ECD B","Grade 1","Grade 2","Grade 3","Grade 4","Grade 5","Grade 6","Grade 7"];
const subjects = ["Physical Education and Arts","Social Science","Science and Technology","Mathematics","English","ChiShona"];
const types = ["lesson","assessment","project"];
const id = () => require("crypto").randomUUID();
const clean = (v,max=5000) => String(v ?? "").trim().slice(0,max);
function requireAuth(req,res,next){ if(!req.session.user) return res.status(401).json({error:"Please sign in."}); next(); }
function requireRole(...allowed){return (req,res,next)=>{if(!req.session.user)return res.status(401).json({error:"Please sign in."});if(!allowed.includes(req.session.user.role))return res.status(403).json({error:"Your account is not permitted to do that."});next();};}
function publicUser(u){return {id:u.id,name:u.name,username:u.username,role:u.role};}
function validPassword(p){return typeof p==="string" && p.length>=12 && p.length<=128;}
function validUsername(u){return /^[a-zA-Z0-9._-]{3,40}$/.test(u||"");}
function safeContent(body, existing={}) {
 const c={
  id: clean(body.id || existing.id || id(),80),
  type: clean(body.type ?? existing.type,20),
  grade: clean(body.grade ?? existing.grade,30),
  subject: clean(body.subject ?? existing.subject,80),
  term: clean(body.term ?? existing.term ?? "Any term",30),
  title: clean(body.title ?? existing.title,180),
  topic: clean(body.topic ?? existing.topic,500),
  body: clean(body.body ?? existing.body,12000),
  questions: clean(body.questions ?? existing.questions,12000),
  answers: clean(body.answers ?? existing.answers,12000),
  published: body.published === true || body.published === 1 || (body.published === undefined && existing.published === 1) ? 1 : 0
 };
 if(!types.includes(c.type))throw Error("Choose a valid content type.");
 if(!grades.includes(c.grade))throw Error("Choose a valid school level.");
 if(!subjects.includes(c.subject))throw Error("Choose a valid subject.");
 if(!c.title)throw Error("Title is required.");
 return c;
}
function recordChange(userId, entityId, action, result="ok"){
 db.prepare("INSERT INTO sync_changes(user_id,entity_id,action,result) VALUES(?,?,?,?)").run(userId,entityId,action,result);
}
app.get("/api/health",(req,res)=>res.json({ok:true,app:"Chikandamina Academy",version:"0.2.0"}));
app.get("/api/setup-status",(req,res)=>res.json({setupRequired:db.prepare("SELECT COUNT(*) n FROM users").get().n===0}));
app.post("/api/setup",setupLimiter,async(req,res)=>{
 if(db.prepare("SELECT COUNT(*) n FROM users").get().n!==0)return res.status(403).json({error:"Initial setup is already complete. Ask an administrator to create accounts."});
 const setupKey=process.env.INITIAL_ADMIN_SETUP_KEY;
 if(!setupKey || clean(req.body.setupKey,200)!==setupKey)return res.status(403).json({error:"Invalid setup key. Configure INITIAL_ADMIN_SETUP_KEY in .env."});
 const name=clean(req.body.name,100), username=clean(req.body.username,40), password=req.body.password;
 if(name.length<2 || !validUsername(username) || !validPassword(password))return res.status(400).json({error:"Enter a name, username (3–40 letters/numbers/._-) and password of at least 12 characters."});
 const hash=await bcrypt.hash(password,12);
 try{
  const info=db.prepare("INSERT INTO users(name,username,password_hash,role) VALUES(?,?,?,'admin')").run(name,username,hash);
  req.session.regenerate(err=>{if(err)return res.status(500).json({error:"Could not start session."});req.session.user={id:Number(info.lastInsertRowid),name,username,role:"admin"};res.json({user:req.session.user});});
 }catch(e){res.status(400).json({error:"Could not create administrator. Choose a different username."});}
});
app.post("/api/login",loginLimiter,async(req,res)=>{
 const username=clean(req.body.username,40), password=String(req.body.password||"");
 const u=db.prepare("SELECT * FROM users WHERE username=? COLLATE NOCASE").get(username);
 if(!u || !u.active || !(await bcrypt.compare(password,u.password_hash)))return res.status(401).json({error:"Incorrect username or password, or account is inactive."});
 req.session.regenerate(err=>{if(err)return res.status(500).json({error:"Could not start session."});req.session.user=publicUser(u);res.json({user:req.session.user});});
});
app.post("/api/logout",(req,res)=>req.session.destroy(()=>{res.clearCookie("ca.sid",{httpOnly:true,sameSite:"lax",secure:isProduction});res.json({ok:true});}));
app.get("/api/me",requireAuth,(req,res)=>res.json({user:req.session.user}));
app.get("/api/users",requireRole("admin"),(req,res)=>res.json({users:db.prepare("SELECT id,name,username,role,active,created_at FROM users ORDER BY role,name").all()}));
app.post("/api/users",requireRole("admin"),async(req,res)=>{
 const name=clean(req.body.name,100),username=clean(req.body.username,40),password=req.body.password,role=clean(req.body.role,20);
 if(name.length<2 || !validUsername(username) || !validPassword(password) || !roles.includes(role))return res.status(400).json({error:"Check name, username, role and password (at least 12 characters)."});
 try{const hash=await bcrypt.hash(password,12);const r=db.prepare("INSERT INTO users(name,username,password_hash,role) VALUES(?,?,?,?)").run(name,username,hash,role);res.status(201).json({user:{id:Number(r.lastInsertRowid),name,username,role,active:1}})}catch(e){res.status(400).json({error:"Username already exists or user could not be created."})}
});
app.patch("/api/users/:id",requireRole("admin"),(req,res)=>{
 const target=db.prepare("SELECT * FROM users WHERE id=?").get(Number(req.params.id));
 if(!target)return res.status(404).json({error:"User not found."});
 const active=req.body.active===false||req.body.active===0?0:1;
 if(target.id===req.session.user.id && active===0)return res.status(400).json({error:"You cannot deactivate your own account."});
 db.prepare("UPDATE users SET active=? WHERE id=?").run(active,target.id);
 res.json({ok:true,id:target.id,active});
});
app.get("/api/content",requireAuth,(req,res)=>{
 const role=req.session.user.role;
 const rows=(role==="admin"||role==="teacher")
  ? db.prepare("SELECT * FROM content ORDER BY updated_at DESC").all()
  : db.prepare("SELECT * FROM content WHERE published=1 ORDER BY updated_at DESC").all();
 res.json({items:rows});
});
app.post("/api/content",requireRole("admin","teacher"),(req,res)=>{
 try{const c=safeContent(req.body);const published=req.session.user.role==="admin"?c.published:0;
 db.prepare(`INSERT INTO content(id,type,grade,subject,term,title,topic,body,questions,answers,published,updated_by)
 VALUES(@id,@type,@grade,@subject,@term,@title,@topic,@body,@questions,@answers,@published,@updated_by)`).run({...c,published,updated_by:req.session.user.id});
 recordChange(req.session.user.id,c.id,"create");
 res.status(201).json({item:db.prepare("SELECT * FROM content WHERE id=?").get(c.id)});
 }catch(e){res.status(400).json({error:e.message||"Could not save content."})}
});
app.put("/api/content/:id",requireRole("admin","teacher"),(req,res)=>{
 const old=db.prepare("SELECT * FROM content WHERE id=?").get(clean(req.params.id,80));
 if(!old)return res.status(404).json({error:"Content not found."});
 try{const c=safeContent({...old,...req.body,id:old.id},old);
 if(req.session.user.role!=="admin")c.published=old.published;
 db.prepare(`UPDATE content SET type=@type,grade=@grade,subject=@subject,term=@term,title=@title,topic=@topic,body=@body,questions=@questions,answers=@answers,published=@published,updated_at=CURRENT_TIMESTAMP,updated_by=@updated_by WHERE id=@id`).run({...c,updated_by:req.session.user.id});
 recordChange(req.session.user.id,c.id,"update");
 res.json({item:db.prepare("SELECT * FROM content WHERE id=?").get(c.id)});
 }catch(e){res.status(400).json({error:e.message||"Could not update content."})}
});
app.delete("/api/content/:id",requireRole("admin","teacher"),(req,res)=>{
 const c=db.prepare("SELECT id FROM content WHERE id=?").get(clean(req.params.id,80));
 if(!c)return res.status(404).json({error:"Content not found."});
 db.prepare("DELETE FROM content WHERE id=?").run(c.id);recordChange(req.session.user.id,c.id,"delete");res.json({ok:true});
});
app.post("/api/sync",requireAuth,(req,res)=>{
 // Client can submit only content mutations. Server re-checks the signed-in role on every sync.
 const changes=Array.isArray(req.body.changes)?req.body.changes.slice(0,30):[];
 const results=[];
 for(const ch of changes){
  try{
   if(!ch || !["upsert","delete"].includes(ch.action))throw Error("Unsupported offline change.");
   if(ch.action==="delete"){
    if(!["admin","teacher"].includes(req.session.user.role))throw Error("Only teachers and administrators may remove content.");
    const itemId=clean(ch.id,80);db.prepare("DELETE FROM content WHERE id=?").run(itemId);recordChange(req.session.user.id,itemId,"offline-delete");results.push({clientId:ch.clientId,ok:true});continue;
   }
   if(!["admin","teacher"].includes(req.session.user.role))throw Error("Your account cannot publish or edit content.");
   const existing=ch.id?db.prepare("SELECT * FROM content WHERE id=?").get(clean(ch.id,80)):null;
   const c=safeContent({...((ch.data)||{}),id:clean(ch.id,80)},existing||{});
   if(existing){
    if(req.session.user.role!=="admin")c.published=existing.published;
    db.prepare(`UPDATE content SET type=@type,grade=@grade,subject=@subject,term=@term,title=@title,topic=@topic,body=@body,questions=@questions,answers=@answers,published=@published,updated_at=CURRENT_TIMESTAMP,updated_by=@updated_by WHERE id=@id`).run({...c,updated_by:req.session.user.id});
   }else{
    c.published=req.session.user.role==="admin"?c.published:0;
    db.prepare(`INSERT INTO content(id,type,grade,subject,term,title,topic,body,questions,answers,published,updated_by) VALUES(@id,@type,@grade,@subject,@term,@title,@topic,@body,@questions,@answers,@published,@updated_by)`).run({...c,updated_by:req.session.user.id});
   }
   recordChange(req.session.user.id,c.id,"offline-upsert");results.push({clientId:ch.clientId,ok:true,serverId:c.id});
  }catch(e){results.push({clientId:ch&&ch.clientId,ok:false,error:e.message||"Sync failed."})}
 }
 res.json({results,items:db.prepare("SELECT * FROM content WHERE published=1 ORDER BY updated_at DESC").all()});
});
app.use(express.static(path.join(__dirname,"public"),{extensions:["html"]}));
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log(`Chikandamina Academy running at http://localhost:${PORT}`));
